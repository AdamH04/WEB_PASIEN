<?php

namespace App\Models;

use CodeIgniter\Model;

class PasienModel extends Model
{
    protected $table = 'pasien';
    protected $primaryKey = 'id';
    protected $useOfTimestamps = True;
    protected $allowedFields = ['no_rm', 'nama', 'umur', 'jenis_kelamin', 'diagnosa'];

    public function getPasien($nama = false)
    {

        if ($nama == false) {
            return $this->findAll();
        }

        return $this->where(['nama' => $nama])->first();
    }
}
