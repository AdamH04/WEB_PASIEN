<?php

namespace App\Controllers;

use App\Models\PasienModel;

class Pasien extends BaseController
{
    protected $pasienModel;

    public function __construct()
    {
        $this->pasienModel = new PasienModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Daftar Pasien',
            'pasien' => $this->pasienModel->getPasien()
        ];

        return view('pasien/index', $data);
    }

    public function detail($nama)
    {
        $pasien = $this->pasienModel->getPasien($nama);
        $data = [
            'title' => 'Detail pasien',
            'pasien' => $this->pasienModel->getPasien($nama)
        ];

        if (empty($data['pasien'])) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('no_rm pasien' . $nama . 'Tidak ditemukan');
        }
        return view('pasien/detail', $data);
    }

    public function create()
    {
        $data = [
            'title' => 'Form Tambah Data pasien',
            'validation' => \Config\Services::validation()
        ];

        return view('pasien/create', $data);
    }

    public function save()
    {
        if (!$this->validate([
            'no_rm' => [
                'rules' => 'required|is_unique[pasien.no_rm]',
                'errors' => [
                    'required' => '{field} harus diisi.',
                    'is_unique' => '{field} sudah terdaftar'
                ]
            ]

        ])) {
            $validation = \Config\Services::validation();
            return redirect()->to('/pasien/create')->withInput()->with('validation', $validation);
        }

        $nama = url_title($this->request->getVar('no_rm'), '-', true);
        $this->pasienModel->save([
            'no_rm' => $this->request->getVar('no_rm'),
            'nama' => $nama,
            'umur' => $this->request->getVar('umur'),
            'jenis_kelamin' => $this->request->getVar('jenis_kelamin'),
            'diagnosa' => $this->request->getVar('diagnosa')
        ]);

        session()->setFlashdata('pesan', 'Data berhasil ditambah');

        return redirect()->to('/pasien');
    }

    public function delete()
    {
        $this->pasienModel->delete('id');
        return redirect()->to('/pasien');
        session()->setFlashdata('pesan', 'Data berhasil dihapus');
    }

    public function edit($nama)
    {
        $data = [
            'title' => 'Form Ubah Data pasien',
            'validation' => \Config\Services::validation(),
            'pasien' => $this->pasienModel->getPasien($nama)
        ];

        return view('pasien/edit', $data);
    }

    public function update($id)
    {
        $pasienLama = $this->pasienModel->getPasien($this->request->getVar('nama'));
        if ($pasienLama['no_rm'] == $this->request->getVar('no_rm')) {
            $rule_no_rm = 'required';
        } else {
            $rule_no_rm = 'required|is_unique[pasien.no_rm]';
        }

        if (!$this->validate([
            'no_rm' => [
                'rules' => $rule_no_rm,
                'errors' => [
                    'required' => '{field} harus diisi.',
                    'is_unique' => '{field} sudah terdaftar'
                ]
            ]

        ])) {
            $validation = \Config\Services::validation();
            return redirect()->to('/pasien/edit/' . $this->request->getVar('nama'))->withInput()->with('validation', $validation);
        }

        $nama = url_title($this->request->getVar('no_rm'), '-', true);
        $this->pasienModel->save([
            'id' => $id,
            'no_rm' => $this->request->getVar('no_rm'),
            'nama' => $nama,
            'umur' => $this->request->getVar('umur'),
            'jenis_kelamin' => $this->request->getVar('jenis_kelamin'),
            'diagnosa' => $this->request->getVar('diagnosa')
        ]);

        session()->setFlashdata('pesan', 'Data berhasil diubah');

        return redirect()->to('/pasien');
    }
}
