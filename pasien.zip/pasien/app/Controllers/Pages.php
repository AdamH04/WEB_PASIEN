<?php

namespace App\Controllers;

class Pages extends BaseController
{

    public function index()
    {

        $data = [
            'title' => 'Halaman utama'
        ];

        echo view('pages/home', $data);
    }

    public function pasien()
    {
        $data = [
            'title' => 'Novel'
        ];
        echo view('pasien/index', $data);
    }
}
