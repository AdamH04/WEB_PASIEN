<?php $this->extend('layout/template'); ?>
<?php $this->section('content'); ?>

<div class="container">
    <div class="row">
        <div class="col">
            <h2>Kelola Data Pasien</h2>
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">Data pasien</h5>
                    <p class="card-text"><b>No.RM : </b><?php echo $pasien['no_rm']; ?></p>
                    <p class="card-text"><b>Nama : </b><?php echo $pasien['nama']; ?></p>
                    <p class="card-text"><b>Umur : </b><?php echo $pasien['umur']; ?></p>
                    <p class="card-text"><b>Jenis Kelamin : </b><?php echo $pasien['jenis_kelamin']; ?></p>
                    <p class="card-text"><b>Diagnosa : </b><?php echo $pasien['diagnosa']; ?></p>

                    <a href="/pasien/edit/<?php echo $pasien['nama']; ?>" class="btn btn-warning">Edit</a>

                    <form action="/pasien/<?php echo $pasien['id']; ?>" method="post" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin hapus data pasien?');">Delete</button>
                    </form>

                    <br><br>

                    <a href="/pasien" class="btn btn-primary">Kembali ke daftar pasien</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->endSection(''); ?>