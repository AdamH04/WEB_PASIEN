<?php $this->extend('layout/template'); ?>
<?php $this->section('content'); ?>

<div class="container">
    <div class="row">
        <div class="col">

            <a href="/pasien/create" class="btn btn-primary mt-3">Tambah data pasien</a>
            <h1 class="mt-2">DAFTAR TABEL PASIEN</h1>

            <?php
            if (session()->getFlashdata('pesan')) : ?>
                <div class="alert alert-success" role="alert">
                    <?php echo session()->getFlashdata('pesan'); ?>
                </div>
            <?php endif; ?>

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">No.</th>
                        <th scope="col">No. RM</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Umur</th>
                        <th scope="col">Jenis Kelamin</th>
                        <th scope="col">Diagnosa</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($pasien as $n) : ?>
                        <tr>
                            <th scope="row"><?= $i++; ?></th>
                            <td><?= $n['no_rm']; ?></td>
                            <td><?= $n['nama']; ?></td>
                            <td><?= $n['umur']; ?></td>
                            <td><?= $n['jenis_kelamin']; ?></td>
                            <td><?= $n['diagnosa']; ?></td>
                            <td>
                                <a href="pasien/<?= $n['nama']; ?>" class="btn btn-success">KELOLA</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $this->endSection(''); ?>