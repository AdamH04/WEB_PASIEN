<?php $this->extend('layout/template'); ?>
<?php $this->section('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-8">
            <h2 class="my-3"> Edit data pasien </h2>

            <form action="/pasien/update/<?php echo $pasien['id']; ?>" method="post">
                <?php csrf_field(); ?>
                <input type="hidden" name="nama" value="<?php echo $pasien['id']; ?>">
                <div class="mb-3">


                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Pasien</label>
                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo (old('nama')) ? old('nama') : $pasien['nama']; ?>">
                    </div>

                    <label for="no_rm" class="form-label">No.RM</label>
                    <input type="text" class="form-control <?php echo ($validation->hasError('no_rm')) ? 'is-invalid' : ''; ?>" id="no_rm" name="no_rm" autofocus value="<?php echo (old('no_rm')) ? old('no_rm') : $pasien['no_rm']; ?>">
                    <div class="invalid-feedback">
                        <?php echo ($validation->getError('no_rm')); ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="umur" class="form-label">Umur</label>
                    <input type="text" class="form-control" id="umur" name="umur" value="<?php echo (old('umur')) ? old('umur') : $pasien['umur']; ?>">
                </div>

                <div class="mb-3">
                    <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                    <input type="text" class="form-control" id="jenis_kelamin" name="jenis_kelamin" value="<?php echo (old('jenis_kelamin')) ? old('jenis_kelamin') : $pasien['jenis_kelamin']; ?>">
                </div>

                <div class="mb-3">
                    <label for="diagnosa" class="form-label">Diagnosa</label>
                    <input type="text" class="form-control" id="diagnosa" name="diagnosa" value="<?php echo (old('diagnosa')) ? old('diagnosa') : $pasien['diagnosa']; ?>">
                </div>

                <button type="submit" class="btn btn-primary">Simpan</button>
            </form>

        </div>
    </div>
</div>

<?php $this->endSection(''); ?>