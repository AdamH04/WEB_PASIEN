<?php $this->extend('layout/template'); ?>

<?php $this->section('content'); ?>

<h1>DATA PASIEN</h1>

<?php $this->endSection(''); ?>